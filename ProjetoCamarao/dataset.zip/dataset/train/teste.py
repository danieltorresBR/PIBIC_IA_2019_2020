import cv2 as cv
print(cv.__version__)